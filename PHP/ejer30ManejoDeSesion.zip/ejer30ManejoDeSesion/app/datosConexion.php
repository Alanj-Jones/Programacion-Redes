<?php

    define("SERVER","bo8xqpmv6pcn043hxakt-mysql.services.clever-cloud.com");
    define("USUARIO","uam2c6y2fgk1boig");
    define("PASS","JXfnlXNbLfE9C6V3TlPw");
    define("BASE","bo8xqpmv6pcn043hxakt");

?>